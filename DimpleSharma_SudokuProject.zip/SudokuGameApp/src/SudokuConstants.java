public interface SudokuConstants {

	int ROWS = 9;
	int COLS = 9;
	
	int MINNUM = 1;
	int MAXNUM = 9;
}